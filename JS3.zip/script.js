let resultisgiven = false; //для работы кнопки равно
let content = document.getElementById('outputField');

//отображение введенных чисел
(function () {
	var z = document.getElementsByClassName('numbers');
	for (let i = 0; i < z.length; i++) {
	  z[i].	addEventListener('click', function() {if (content.textContent == 0 || resultisgiven == true){
		    content.innerHTML = '';
		    resultisgiven = false;
	        }
		  content.append(this.textContent);});
	}

}) ()

//переменная - объект, по примеру из лекции
var operation = {
	first: 0,
	typeofoperation: "start",
	result: 0,
	action: function(second){
		if (this.typeofoperation == "summa") this.result = +this.first + second;
		if (this.typeofoperation == "raznost") this.result = this.first - second;
		if (this.typeofoperation == "proizvedenie") this.result = this.first * second;
		if (this.typeofoperation == "chastnoe") this.result = this.first / second;
	}
}

//функция выполнения операции над числами. именно здесь я расчитывал применить bind, но this работает без него.
function schablone(kindofoperation) {
  if (operation.typeofoperation != "start") {
    operation.action(+content.textContent);
    operation.typeofoperation = kindofoperation;
    console.log(operation.result);
    operation.first = operation.result;
  }
  else {
  	operation.typeofoperation = kindofoperation;
	operation.first = content.textContent;
  }
  content.innerHTML = 0;
}


//сложение
let buttonplus = document.getElementById("button+");

buttonplus.addEventListener('click', function () {
	schablone('summa');
} );

//вычитание
let buttonminus = document.getElementById("button-");

buttonminus.addEventListener('click', function () {
	schablone('raznost');
} );

//умножение
let buttonumnozh = document.getElementById("button*");

buttonumnozh.addEventListener('click', function () {
	schablone('proizvedenie');
} );

//деление
let buttondelenie = document.getElementById("button/");

buttondelenie.addEventListener('click', function () {
	schablone('chastnoe');
} );

//равно
let buttonravno = document.getElementById("button=");

buttonravno.addEventListener('click', function () {
  operation.action(+content.textContent);
  console.log(operation.result);
  content.innerHTML = operation.result;
  operation.first = 0;
  operation.result = 0;
  operation.typeofoperation = "start";
  resultisgiven = true;
});

//очистить
let buttonclear = document.getElementById("buttonc");

buttonclear.addEventListener('click', function () {
  operation.first = 0;
  operation.typeofoperation = "start";
  result = 0;
  content.innerHTML = 0;
});

//тема привязки контекста здесь не раскрыта
//теоретически про bind, call, apply и join, и даже про каррирование функций все понятно
//пока читаешь это на learn.javascript
//но как это применить на практике, для меня осталось неясным( калькулятор заработал без всего этого
//для каррирования нужна функция с несколькими аргументами, как я понял, но здесь ее просто некуда вставить(
//сдаюсь.
//сделать калькулятор оказалось несложно. а вот сделать искусственно потерю контекста не удалось.
//очень нужен разбор этого задания на примере правильно сделанного калькулятора.