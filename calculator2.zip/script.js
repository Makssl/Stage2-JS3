let content = document.getElementById('outputField');
let content2 = document.getElementById('resultField');
let typeOfOperation = 4;
let result = 0;

(function () {
	let numb = document.getElementsByClassName('numbers');
	for (let i = 0; i < numb.length; i++) {
	  numb[i].addEventListener('click', function() {
		  if (content.textContent == 0) {
		 	 content.innerHTML = '';
	      }
		  content.append(this.textContent);
	  });
	}
	let operat = document.getElementsByClassName('operations');
	for (let i = 0; i < operat.length; i++) {
		operat[i].addEventListener('click', function() {
			if (this.id != 'clear') {
				if(typeOfOperation != 4 ) {
					result = operations[typeOfOperation](+content2.textContent,+content.textContent);
					content2.innerHTML = result;
				}
				else {
					content2.innerHTML = content.textContent;
				}
				typeOfOperation = this.id;
			}
			else {
				content2.innerHTML = 0;
				typeOfOperation = 4;
				result = 0;	
			}
			content.innerHTML = 0;
		});
	}
}) ()

function operation(metod, firstElement, secondElement) {
	switch (metod) {
		case 'addition':
			return firstElement + secondElement;
		case 'substraction':
			return firstElement - secondElement;
		case 'multiplication':
			return firstElement * secondElement;
		case 'division':
			return firstElement / secondElement;
	}
}

let operations = [operation.bind(null, 'addition'), 
			   	  operation.bind(null, 'substraction'), 
			   	  operation.bind(null, 'multiplication'),
			  	  operation.bind(null, 'division')
];